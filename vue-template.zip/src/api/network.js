import axios from 'axios';
import qs from 'qs';

const instance = axios.create({
  baseURL: process.env.VUE_APP_BASE_URL,
  timeout: 5 * 60 * 1000
});

//请求拦截
function requestInterceptor(config) {
  return config;
}
//请求错误拦截
function requestErrorInterceptor(error) {
  return Promise.reject(error);
}
//响应拦截
function responseInterceptor({ data }) {
  return data;
}
//响应错误拦截
function responseErrorInterceptor(error) {
  return Promise.reject(error);
}

instance.interceptors.request.use(requestInterceptor, requestErrorInterceptor);
instance.interceptors.response.use(responseInterceptor, responseErrorInterceptor);

export default {
  get(url, params, config = {}) {
    return instance.get(url, { params, ...config });
  },
  post(url, data, config = {}) {
    return instance.post(url, data, config);
  },
  put(url, data, config = {}) {
    return instance.put(url, data, config);
  },
  delete(url, data, config) {
    return instance.delete(url, { data, ...config });
  },
  form(url, params, config) {
    return instance.post(url, qs.stringify(params), config);
  }
};
