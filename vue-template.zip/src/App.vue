<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="stylus">
#app{
  overflow: auto
  width: 100%;
  height: 100%;
}
</style>
