module.exports = {
  publicPath: './',
  // outputDir:'',
  css: {
    loaderOptions: {
      stylus: {
        import: '~@/assets/styl/base.styl'
      }
    }
  },
  productionSourceMap: false,
  //运行时编译模板
  runtimeCompiler: true,
  devServer: {
    // eslint-disable-next-line no-unused-vars
    before(app) {},
    proxy: {
      '/api': {
        target: 'http://10.221.182.140:8200',
        changeOrigin: true,
        pathRewrite: {
          '^/api': ''
        }
      }
    }
  }
};
